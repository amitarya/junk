/*
 * This is to test the threadPool library. We will check if each thread
 * gets a fair chance. From the output we see each job is run by which
 * We spawn 50 jobs and see if all the threads did a fair share. Note
 * This is just for the testing purpose as we have put a sleep in the
 * ThreadPool::Run method. In reality threads may not get a fair share.
 */

#include "threadPool.h"
#include <iostream>
#include <map>


using namespace std;
mutex coutMutex;
mutex threadJobsCountMutex;
map<thread::id, int> threadJobsCount;
const int NJobs = 10;
const int NThreads = 3;
void testFunction(int a) {
	{ 
		lock_guard<mutex> lock(threadJobsCountMutex);
		threadJobsCount[this_thread::get_id()]++;
	}
	{
		lock_guard<mutex> lock(coutMutex);
		cout << "Job " << a << " was done by thread with id --> "  << this_thread::get_id() << endl;
	}
}

int main() {
	ThreadPool::Init(NThreads);
	for (int i =0;i < NJobs;i++) {
		function<void(int)> f = testFunction;
		ThreadPool::GetInstance()->ScheduleWork(std::bind(f, i));
	}
	ThreadPool::GetInstance()->Join();
	// Test the count of each thread
	map<thread::id, int>::const_iterator iter = threadJobsCount.begin();
	for ( ;iter != threadJobsCount.end(); ++iter) {
		cout << "Thread with id(" << iter->first << ") did " << iter->second <<
			" Jobs" << endl;
	}
}
